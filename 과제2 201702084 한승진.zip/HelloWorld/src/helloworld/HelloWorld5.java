package helloworld;

import java.util.Random;
import java.util.Scanner;

public class HelloWorld5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		      Random r = new Random();
		      Scanner s = new Scanner(System.in);

		      String me;
		      int stage = 0, mewin = 0, comwin = 0;

		      while (stage < 7) {
		         System.out.println("���� ���� �� �� �ϳ��� �Է��ϼ���");
		      System.out.println();
		         int com = (int) (Math.random() * 10) + 1;
		         me = s.nextLine();
		         if (me.equals("����")) {
		            if (com % 3 == 0) {
		               System.out.println("�̰���ϴ�!");
		               mewin++;
		               stage++;
		            } else if (com % 3 == 1 || com == 1) {
		               System.out.println("�����ϴ�.");
		               stage++;
		            } else {
		               System.out.println("�����ϴ�.");
		               comwin++;
		               stage++;
		            }

		         } else if (me.equals("����")) {
		            if (com % 3 == 0) {
		               System.out.println("�����ϴ�.");
		               comwin++;
		               stage++;
		            } else if (com % 3 == 1 || com == 1) {
		               System.out.println("�̰���ϴ�.");
		               mewin++;
		               stage++;
		            } else {
		               System.out.println("�����ϴ�.");
		               stage++;
		            }

		         } else if (me.equals("��")) {
		            if (com % 3 == 0) {
		               System.out.println("�����ϴ�.");
		               stage++;
		            } else if (com % 3 == 1 || com == 1) {
		               System.out.println("�����ϴ�.");
		               comwin++;
		               stage++;
		            } else {
		               System.out.println("�̰���ϴ�!.");
		               mewin++;
		               stage++;
		            }

		         } else {
		            System.out.println("�ٽ� �Է��ϼ���");
		         }
		         System.out.println(); 
		      }
		      if (mewin > comwin) {
		         System.out.println("���� me");
		      } else if (mewin < comwin) {
		         System.out.println("���� com");
		      } else {
		         System.out.println("����.!");
		      }

		   }

	}
