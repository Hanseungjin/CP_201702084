package helloworld;

import java.util.Scanner;

public class HelloWorld3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.println("���ĺ��� �Է��ϼ���.");
		
		String str=input.next();
		char alphabet=str.charAt(0);
		
		switch(alphabet) {
		case 'a':case 'e':case 'i':case 'o':case 'u':
		case 'A':case 'E':case 'I':case 'O':case 'U':
				System.out.println("����");
				break;
		default:
				System.out.println("����");
				break;
		}
						
		

	}

}