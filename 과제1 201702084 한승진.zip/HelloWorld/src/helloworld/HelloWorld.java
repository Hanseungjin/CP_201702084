package helloworld;

import java.util.Scanner;
public class HelloWorld {
   public static void main(String[] args) {
      // TODO Auto-generated method stub
      Scanner s = new Scanner(System.in);
      int a = 0, b = 0, c = 0;
      int me = 0;
   
      System.out.println("��ȯ �� �� �Է�:");
      me = s.nextInt();
      a = me;
      while (a >= 60 || b >=60) {

         if (a >= 60) {
            a -= 60;
            b++;
         } else if (b >= 60) {
            b -= 60;
            c++;
         }
      }
      System.out.println(me + "�ʴ� " + c + "�ð�" + b + "��" + a + "���Դϴ�.");
   }
}