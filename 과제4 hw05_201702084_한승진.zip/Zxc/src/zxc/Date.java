package zxc;

import java.util.Scanner;

public class Date {
   int year;
   int month;
   int day;
   String a;
   public Date() {

   }
   public void printEastern() {

      System.out.println("����� ��¥ ǥ�� : " + year + "." + month + "." + day);

   }

   public void printWestern() {

      if (month == 1) {
         a = "January";
      } else if (month == 2) {
         a = "February";
      } else if (month == 3) {
         a = "March";
      } else if (month == 4) {
         a = "April";
      } else if (month == 5) {
         a = "May";
      } else if (month == 6) {
         a = "June";
      } else if (month == 7) {
         a = "July";
      } else if (month == 8) {
         a = "August";
      } else if (month == 9) {
         a = "september";
      } else if (month == 10) {
         a = "Otober";
      } else if (month == 11) {
         a = "November";
      } else if (month == 12) {
         a = "December";
      }
      System.out.println("�̱��� ��¥ ǥ�� : " + a + "." + day + "." + year);
   }

}