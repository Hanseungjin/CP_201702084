package zxc;

import java.util.Scanner;

public class Zxc {

   public static void main(String[] args) {
      // TODO Auto-generated method stub
      Scanner s = new Scanner(System.in);

      System.out.println("���ڸ� �Է��Ͻÿ�.");
      String a = s.nextLine();
      char[] b;
      b = a.toCharArray();

      for (int i = 0; i < a.length(); i++) {
         if (b[i] >= 65 && b[i] <= 90) {
            b[i] += 32;
         } else if (b[i] >= 97 && b[i] <= 122) {
            b[i] -= 32;
         }

      }
      System.out.println(b);
   }
}