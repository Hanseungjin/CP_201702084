package zxc;

import java.util.Scanner;

public class DateTest {

   public static void main(String[] args) {
      // TODO Auto-generated method stub
      Scanner s = new Scanner(System.in);
      Date date = new Date();
      System.out.println("���� �Է� : ");
      date.year = s.nextInt();
      System.out.println("�� �Է� : ");
      date.month = s.nextInt();
      System.out.println("�� �Է� : ");
      date.day = s.nextInt();
      date.printEastern();
      date.printWestern();
   }

}